﻿using Npgsql;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace pract6_11_01_
{
    /// <summary>
    /// Логика взаимодействия для ChangePasswordWindow.xaml
    /// </summary>
    public partial class ChangePasswordWindow : Window
    {
        private readonly string connectionString = "Host=localhost;Port=5432;Database=Shaposnikov;Username=postgres;Password=postgres";
        private readonly string employeeLogin;
        public ChangePasswordWindow(string login)
        {
            InitializeComponent();
            employeeLogin = login;
        }
        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            string newPasswordText = NewPasswordTextBox.Text;
            string confirmPasswordText = ConfirmPasswordTextBox.Text;

            // Проверка на пустые поля
            if (string.IsNullOrWhiteSpace(newPasswordText) || string.IsNullOrWhiteSpace(confirmPasswordText))
            {
                MessageBox.Show("Пожалуйста, заполните оба поля пароля.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            // Проверка на совпадение паролей
            if (newPasswordText != confirmPasswordText)
            {
                MessageBox.Show("Пароли не совпадают.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            // Проверка, что пароль — число
            if (!int.TryParse(newPasswordText, out int newPassword))
            {
                MessageBox.Show("Пароль должен быть числом.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            try
            {
                using (var connection = new NpgsqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "UPDATE public.sotrudniki SET password = @password WHERE login = @login";
                    using (var command = new NpgsqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("password", newPassword);
                        command.Parameters.AddWithValue("login", employeeLogin);

                        int rowsAffected = command.ExecuteNonQuery();
                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Пароль успешно изменён.", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
                            this.DialogResult = true;
                            this.Close();
                        }
                        else
                        {
                            MessageBox.Show("Не удалось изменить пароль.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                        }
                    }
                }
            }
            catch (NpgsqlException ex)
            {
                MessageBox.Show($"Ошибка подключения к базе данных: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            catch (System.Exception ex)
            {
                MessageBox.Show($"Произошла ошибка: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}