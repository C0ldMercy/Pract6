﻿using Npgsql;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace pract6_11_01_
{
    /// <summary>
    /// Логика взаимодействия для EmployeeFormWindow.xaml
    /// </summary>
    public partial class EmployeeFormWindow : Window
    {
        private readonly string connectionString = "Host=localhost;Port=5432;Database=Shaposnikov;Username=postgres;Password=postgres";
        private readonly bool isEditMode;
        private readonly Employee employee;
        public EmployeeFormWindow(bool isEditMode = false, Employee employee = null)
        {
            InitializeComponent();
            this.isEditMode = isEditMode;
            this.employee = employee;

            if (isEditMode && employee != null)
            {
                TitleTextBlock.Text = "Редактирование сотрудника";
                FioTextBox.Text = employee.Fio;
                LoginTextBox.Text = employee.Login;
                PasswordTextBox.Text = employee.Password.ToString();
                StahTextBox.Text = employee.Stah.ToString();
                DolzhostTextBox.Text = employee.Dolzhost;
                LoginTextBox.IsEnabled = false; // Логин нельзя менять при редактировании
            }
        }
        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            // Валидация полей
            if (string.IsNullOrWhiteSpace(FioTextBox.Text) || string.IsNullOrWhiteSpace(LoginTextBox.Text) ||
                string.IsNullOrWhiteSpace(PasswordTextBox.Text) || string.IsNullOrWhiteSpace(StahTextBox.Text) ||
                string.IsNullOrWhiteSpace(DolzhostTextBox.Text))
            {
                MessageBox.Show("Пожалуйста, заполните все поля.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            if (!int.TryParse(PasswordTextBox.Text, out int password))
            {
                MessageBox.Show("Пароль должен быть числом.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            if (!int.TryParse(StahTextBox.Text, out int stah))
            {
                MessageBox.Show("Стаж должен быть числом.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            try
            {
                using (var connection = new NpgsqlConnection(connectionString))
                {
                    connection.Open();
                    if (isEditMode)
                    {
                        // Обновление существующего сотрудника
                        string query = "UPDATE public.sotrudniki SET fio = @fio, password = @password, stah = @stah, dolzhost = @dolzhost WHERE login = @login";
                        using (var command = new NpgsqlCommand(query, connection))
                        {
                            command.Parameters.AddWithValue("fio", FioTextBox.Text);
                            command.Parameters.AddWithValue("login", LoginTextBox.Text);
                            command.Parameters.AddWithValue("password", password);
                            command.Parameters.AddWithValue("stah", stah);
                            command.Parameters.AddWithValue("dolzhost", DolzhostTextBox.Text);

                            int rowsAffected = command.ExecuteNonQuery();
                            if (rowsAffected > 0)
                            {
                                MessageBox.Show("Данные сотрудника успешно обновлены.", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
                                this.DialogResult = true;
                                this.Close();
                            }
                            else
                            {
                                MessageBox.Show("Не удалось обновить данные сотрудника.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                            }
                        }
                    }
                    else
                    {
                        // Добавление нового сотрудника
                        string query = "INSERT INTO public.sotrudniki (fio, login, password, stah, dolzhost) VALUES (@fio, @login, @password, @stah, @dolzhost)";
                        using (var command = new NpgsqlCommand(query, connection))
                        {
                            command.Parameters.AddWithValue("fio", FioTextBox.Text);
                            command.Parameters.AddWithValue("login", LoginTextBox.Text);
                            command.Parameters.AddWithValue("password", password);
                            command.Parameters.AddWithValue("stah", stah);
                            command.Parameters.AddWithValue("dolzhost", DolzhostTextBox.Text);

                            int rowsAffected = command.ExecuteNonQuery();
                            if (rowsAffected > 0)
                            {
                                MessageBox.Show("Сотрудник успешно добавлен.", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
                                this.DialogResult = true;
                                this.Close();
                            }
                            else
                            {
                                MessageBox.Show("Не удалось добавить сотрудника.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                            }
                        }
                    }
                }
            }
            catch (NpgsqlException ex)
            {
                MessageBox.Show($"Ошибка подключения к базе данных: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            catch (System.Exception ex)
            {
                MessageBox.Show($"Произошла ошибка: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
    
